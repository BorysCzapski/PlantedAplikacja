package com.example.plantcareapp.data;


import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.plantcareapp.data.dao.PlantDao;
import com.example.plantcareapp.data.model.Plant;
import java.util.List;

public class PlantRepository {

    private PlantDao mPlantDao;
    private LiveData<List<Plant>> mAllPlants;

    public PlantRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        mPlantDao = db.plantDao();
        mAllPlants = mPlantDao.getAllPlants();
    }

    public LiveData<List<Plant>> getAllPlants() {
        return mAllPlants;
    }

    public void insert(Plant plant) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            mPlantDao.insert(plant);
        });
    }

    public void updateLastWatered(int plantId, long timestamp) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            mPlantDao.updateLastWatered(plantId, timestamp);
        });
    }

    // Metoda dla Workera
    public List<Plant> getAllPlantsForWorker() {
        return mPlantDao.getAllPlantsForWorker();
    }
}