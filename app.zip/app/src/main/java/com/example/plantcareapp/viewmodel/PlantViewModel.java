package com.example.plantcareapp.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.plantcareapp.data.model.Plant;
import com.example.plantcareapp.data.PlantRepository;
import java.util.List;

public class PlantViewModel extends AndroidViewModel {

    private PlantRepository mRepository;
    private final LiveData<List<Plant>> mAllPlants;

    public PlantViewModel(Application application) {
        super(application);
        mRepository = new PlantRepository(application);
        mAllPlants = mRepository.getAllPlants();
    }

    public LiveData<List<Plant>> getAllPlants() {
        return mAllPlants;
    }

    public void insert(Plant plant) {
        mRepository.insert(plant);
    }

    public void waterPlant(Plant plant) {
        mRepository.updateLastWatered(plant.id, System.currentTimeMillis());
    }
}