package com.example.plantcareapp.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.plantcareapp.data.model.Plant;

import java.util.List;

@Dao
public interface PlantDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Plant plant);

    @Query("SELECT * FROM plants_table ORDER BY name ASC")
    LiveData<List<Plant>> getAllPlants();

    @Query("UPDATE plants_table SET last_watered_timestamp = :timestamp WHERE id = :plantId")
    void updateLastWatered(int plantId, long timestamp);

    // Zapytanie dla Workera - nie może zwracać LiveData
    @Query("SELECT * FROM plants_table")
    List<Plant> getAllPlantsForWorker();
}