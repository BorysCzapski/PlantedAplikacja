package com.example.plantcareapp.data.model;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "plants_table")
public class Plant {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;

    public String species; // Gatunek

    @ColumnInfo(name = "watering_frequency_days")
    public int wateringFrequency; // Częstotliwość podlewania w dniach

    @ColumnInfo(name = "last_watered_timestamp")
    public long lastWatered; // Data ostatniego podlewania (w milisekundach)
}