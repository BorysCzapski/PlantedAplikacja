package com.example.plantcareapp.worker;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.example.plantcareapp.R;
import com.example.plantcareapp.data.PlantRepository;
import com.example.plantcareapp.data.model.Plant;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class WateringCheckWorker extends Worker {

    private Context context;

    public WateringCheckWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        this.context = context;
    }

    @NonNull
    @Override
    public Result doWork() {
        PlantRepository repository = new PlantRepository((Application) getApplicationContext());
        List<Plant> plants = repository.getAllPlantsForWorker();

        for (Plant plant : plants) {
            long daysSinceWatered = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - plant.lastWatered);
            if (daysSinceWatered >= plant.wateringFrequency) {
                sendNotification(plant.name);
            }
        }
        return Result.success();
    }

    private void sendNotification(String plantName) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String CHANNEL_ID = "plant_care_channel";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Powiadomienia o podlewaniu", NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground) // Użyj domyślnej ikony
                .setContentTitle("Czas podlać rośliny!")
                .setContentText("Twoja roślina \"" + plantName + "\" potrzebuje wody.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        // Używamy ID rośliny (lub hasha nazwy), aby powiadomienia mogły się nadpisywać
        notificationManager.notify(plantName.hashCode(), builder.build());
    }
}
