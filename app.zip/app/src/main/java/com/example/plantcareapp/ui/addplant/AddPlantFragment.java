package com.example.plantcareapp.ui.addplant;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;
import com.example.plantcareapp.R;
import com.example.plantcareapp.data.model.Plant;
import com.example.plantcareapp.viewmodel.PlantViewModel;

public class AddPlantFragment extends Fragment {

    private EditText editName, editSpecies, editFrequency;
    private PlantViewModel plantViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_plant, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        editName = view.findViewById(R.id.edit_name);
        editSpecies = view.findViewById(R.id.edit_species);
        editFrequency = view.findViewById(R.id.edit_frequency);
        Button saveButton = view.findViewById(R.id.button_save);

        plantViewModel = new ViewModelProvider(this).get(PlantViewModel.class);

        saveButton.setOnClickListener(v -> {
            if (TextUtils.isEmpty(editName.getText()) || TextUtils.isEmpty(editSpecies.getText()) || TextUtils.isEmpty(editFrequency.getText())) {
                Toast.makeText(getContext(), "Wszystkie pola są wymagane", Toast.LENGTH_SHORT).show();
            } else {
                Plant plant = new Plant();
                plant.name = editName.getText().toString();
                plant.species = editSpecies.getText().toString();
                plant.wateringFrequency = Integer.parseInt(editFrequency.getText().toString());
                plant.lastWatered = System.currentTimeMillis(); // Ustawiamy datę dodania jako ostatnie podlewanie

                plantViewModel.insert(plant);

                // Powrót do dashboardu
                NavHostFragment.findNavController(AddPlantFragment.this).navigateUp();
            }
        });
    }
}