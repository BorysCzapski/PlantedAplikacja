package com.example.plantcareapp.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.example.plantcareapp.R;
import com.example.plantcareapp.data.model.Plant;

import java.util.concurrent.TimeUnit;

public class PlantListAdapter extends ListAdapter<Plant, PlantListAdapter.PlantViewHolder> {

    private final OnWaterButtonClickListener listener;

    public PlantListAdapter(@NonNull DiffUtil.ItemCallback<Plant> diffCallback, OnWaterButtonClickListener listener) {
        super(diffCallback);
        this.listener = listener;
    }

    @NonNull
    @Override
    public PlantViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item_plant, parent, false);
        return new PlantViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PlantViewHolder holder, int position) {
        Plant current = getItem(position);
        holder.bind(current, listener);
    }

    static class PlantViewHolder extends RecyclerView.ViewHolder {
        private final TextView plantNameView;
        private final TextView plantStatusView;
        private final Button waterButton;

        private PlantViewHolder(View itemView) {
            super(itemView);
            plantNameView = itemView.findViewById(R.id.textViewName);
            plantStatusView = itemView.findViewById(R.id.textViewStatus);
            waterButton = itemView.findViewById(R.id.buttonWater);
        }

        public void bind(Plant plant, OnWaterButtonClickListener listener) {
            plantNameView.setText(plant.name + " (" + plant.species + ")");

            long daysSinceWatered = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - plant.lastWatered);
            if (daysSinceWatered >= plant.wateringFrequency) {
                plantStatusView.setText("Wymaga podlania!");
                plantStatusView.setTextColor(itemView.getContext().getResources().getColor(android.R.color.holo_red_dark));
            } else {
                plantStatusView.setText("Wszystko OK (podlano " + daysSinceWatered + " dni temu)");
                plantStatusView.setTextColor(itemView.getContext().getResources().getColor(android.R.color.darker_gray));
            }

            waterButton.setOnClickListener(v -> listener.onWaterButtonClick(plant));
        }
    }

    public static class PlantDiff extends DiffUtil.ItemCallback<Plant> {
        @Override
        public boolean areItemsTheSame(@NonNull Plant oldItem, @NonNull Plant newItem) {
            return oldItem.id == newItem.id;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Plant oldItem, @NonNull Plant newItem) {
            return oldItem.name.equals(newItem.name) &&
                    oldItem.lastWatered == newItem.lastWatered;
        }
    }

    public interface OnWaterButtonClickListener {
        void onWaterButtonClick(Plant plant);
    }
}